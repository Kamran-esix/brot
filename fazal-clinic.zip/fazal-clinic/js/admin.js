import { CONFIG } from './config.js';
import * as DB from './db.js';

const $ = (s) => document.querySelector(s);
const el = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat().forEach((c) => e.append(c));
  return e;
};

const state = { date: null, map: {}, closed: new Set(), unB: () => {}, unC: () => {}, confirm: null, user: null };

function msg(id, text, ok) { const m = $(id); m.textContent = text || ''; m.hidden = !text; m.classList.toggle('ok', !!ok); }
function fail(e) { msg('#panelMsg', e && e.code === 'permission-denied' ? 'Not allowed. Check that you are signed in with a staff account.' : 'Something went wrong. Check the internet and try again.'); }

/* ---------- sign in ---------- */
$('#who-sel').replaceChildren(...CONFIG.staff.map((s) => el('option', { value: s.key }, s.label)));
if (DB.isDemo) $('#demoBar').hidden = false;

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  msg('#loginMsg', '');
  try { await DB.login($('#who-sel').value, $('#pw').value); $('#pw').value = ''; }
  catch (err) {
    msg('#loginMsg', err.message === 'auth/network-request-failed' ? 'No internet connection.' : err.message === 'auth/too-many-requests' ? 'Too many attempts. Wait a few minutes and try again.' : 'Wrong password. Try again.');
  }
});
$('#logout').addEventListener('click', () => DB.logout());

DB.onAuth((u) => {
  state.user = u;
  $('#loginForm').hidden = !!u; $('#panel').hidden = !u;
  $('#who').hidden = !u; $('#logout').hidden = !u; $('#logout').style.display = u ? '' : 'none';
  if (u) { $('#who').textContent = 'Signed in as ' + u.label; start(); }
  else { state.unB(); state.unC(); }
});

/* ---------- day ---------- */
function start() {
  if (!state.date) state.date = DB.candidateDates()[0] || DB.todayKHI();
  $('#day').value = state.date;
  state.unC(); state.unC = DB.watchClosed((set) => { state.closed = set; renderTop(); });
  watchDay();
}
function watchDay() {
  state.unB();
  state.map = {};
  state.unB = DB.watchBookings(state.date, (map, err) => { state.map = map; if (err) fail(err); render(); });
  render();
}
$('#day').addEventListener('change', (e) => { if (e.target.value) { state.date = e.target.value; watchDay(); } });
$('#nextOpen').addEventListener('click', () => {
  let d = DB.addDays(DB.todayKHI(), 0);
  for (let i = 0; i < 60; i++, d = DB.addDays(d, 1)) if (CONFIG.openWeekdays.includes(DB.weekday(d)) && d > (state.date || '')) break;
  state.date = d; $('#day').value = d; watchDay();
});
$('#toggleClosed').addEventListener('click', async () => {
  try { await DB.setClosed(state.date, !state.closed.has(state.date)); } catch (e) { fail(e); }
});

/* ---------- add walk-in ---------- */
$('#addForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  msg('#panelMsg', '');
  try {
    await DB.book(state.date, +$('#addNum').value, $('#addName').value, $('#addLoc').value, { walkIn: true });
    $('#addName').value = ''; $('#addLoc').value = '';
  } catch (err) {
    msg('#panelMsg', err.message === 'taken' ? 'That number was just taken. Pick another.' : err.message === 'closed' ? 'This day is closed. Reopen it first.' : 'Could not add the patient.');
  }
});

/* ---------- render ---------- */
function renderTop() {
  const closed = state.closed.has(state.date);
  $('#toggleClosed').textContent = closed ? 'Reopen this day' : 'Close this day';
  const open = CONFIG.openWeekdays.includes(DB.weekday(state.date));
  msg('#dayNote', closed ? 'This day is closed. Patients cannot book new numbers.' : !open ? 'The clinic is not normally open on this weekday.' : '');
}

function render() {
  renderTop();
  const nums = [...Array(CONFIG.maxPatients).keys()].map((i) => i + 1);
  const booked = nums.filter((n) => state.map[n]);
  const done = booked.filter((n) => state.map[n].status === 'done').length;
  $('#stats').replaceChildren(
    el('span', { class: 'pill' }, `Booked: ${booked.length} / ${CONFIG.maxPatients}`),
    el('span', { class: 'pill' }, `Waiting: ${booked.length - done}`),
    el('span', { class: 'pill' }, `Done: ${done}`),
    el('span', { class: 'pill' }, `Free: ${CONFIG.maxPatients - booked.length}`));

  const sel = $('#addNum'), keep = sel.value;
  sel.replaceChildren(...nums.filter((n) => !state.map[n]).map((n) => el('option', { value: n }, '#' + n)));
  if ([...sel.options].some((o) => o.value === keep)) sel.value = keep;

  $('#rows').replaceChildren(...nums.map((n) => {
    const b = state.map[n];
    const status = !b ? 'Free' : b.status === 'done' ? 'Done' : 'Waiting';
    const key = state.date + '_' + n;
    const acts = el('td', {}, el('div', { class: 'act' }));
    const box = acts.firstChild;
    if (b) {
      box.append(
        el('button', { class: 'btn ghost small', type: 'button', onclick: () => DB.setStatus(state.date, n, b.status === 'done' ? 'booked' : 'done').catch(fail) }, b.status === 'done' ? 'Undo' : 'Mark done'),
        el('button', { class: 'btn ghost small', type: 'button', style: state.confirm === key ? 'border-color:var(--danger);color:var(--danger)' : null, onclick: () => cancelTap(n, key) }, state.confirm === key ? 'Tap again to cancel' : 'Cancel'));
    } else {
      box.append(el('button', { class: 'btn ghost small', type: 'button', onclick: () => { $('#addNum').value = n; $('#addName').focus(); } }, 'Add walk-in'));
    }
    return el('tr', { class: b ? (b.status === 'done' ? 'done' : 'booked') : 'free' },
      el('td', { class: 'n' }, '#' + n),
      el('td', { dir: 'ltr' }, DB.rangeText(n)),
      el('td', {}, b ? b.name : '–'),
      el('td', {}, b ? b.location : '–'),
      el('td', {}, el('span', { class: 'badge ' + status.toLowerCase() }, status)),
      acts);
  }));
}

let confirmTimer;
function cancelTap(n, key) {
  if (state.confirm === key) {
    state.confirm = null; clearTimeout(confirmTimer);
    DB.cancel(state.date, n).catch(fail);
    return;
  }
  state.confirm = key; render();
  clearTimeout(confirmTimer);
  confirmTimer = setTimeout(() => { state.confirm = null; render(); }, 4000);
}
